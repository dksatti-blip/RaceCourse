# RaceCourse

A Unity-based multiplayer off-road racing game prototype.

## Project details

- **Unity Editor:** 6000.3.27f1 (Unity 6.3 LTS)
- **Target development platform:** macOS
- **Input:** Unity Input System
- **Multiplayer:** Netcode for GameObjects and Unity Relay
- **Transport:** Unity Transport

## Included in this repository

- `Assets/` — scenes, scripts, prefabs, materials, UI assets, and other project assets
- `Packages/` — Unity package manifest and lock file
- `ProjectSettings/` — project and editor settings

## Open the project

1. Install Unity Hub and Unity **6000.3.27f1** (or a compatible Unity 6.3 LTS patch).
2. In Unity Hub, choose **Add** / **Open** and select this `RaceCourse` folder.
3. Allow Unity to resolve packages and import assets.
4. Open `Assets/Scenes/SampleScene.unity`.
5. If Unity Services are not linked in your environment, link the project to your own Unity Cloud project and configure Authentication and Relay before testing multiplayer.

## Multiplayer notes

The project uses Unity Authentication, Unity Relay, Netcode for GameObjects, and Unity Transport. Host and Client use separate running game instances. A Host creates a Relay allocation and shares its join code; a Client enters that code to connect.

Relay availability and behavior depend on the Unity Cloud project, service configuration, platform, and network environment. Do not publish private service credentials or account information.

## Current prototype status

The project includes a Host/Join flow and the multiplayer car setup. The uploaded project snapshot is a development prototype, not a finished client release. Car spawn/ground-contact physics still needs validation and tuning before presenting the build as a polished playable demo.

## Build

Use Unity's Build Profiles for your target platform. The source archive intentionally does not include a compiled `.app` build; publish playable builds separately as versioned GitHub Releases.

## Repository hygiene

Generated Unity folders and local machine settings are excluded through `.gitignore`, including `Library/`, `Temp/`, `Logs/`, `Obj/`, and `UserSettings/`. Unity `.meta` files are retained because they preserve asset GUID references.
